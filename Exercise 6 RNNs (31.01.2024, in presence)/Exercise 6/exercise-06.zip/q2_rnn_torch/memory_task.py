import torch

def memory_task_loss(outputs : torch.tensor, 
                     ground_truth : torch.tensor) -> torch.tensor:
    """
    Computes an appropriate classification loss for every character of the predicted
    sequence.
    Args:
        -outputs: a tensor of shape [B, L, C], B being the batch size
        L being the sequence length and C being the unnormalized output
        of the "linear layer" of an RNN, one number for each of the C possible
        classes
        -ground_truth: a tensor of shape [B, L] containing the class indices
        for every sample of every sequence as a number in {0, ..., C-1}
    Returns:
        The average classification loss for all samples
    """
    #####Insert your code here for subtask 2e#####

def memory_task_acc(outputs : torch.tensor, ground_truth : torch.tensor, 
                    to_remember_len : int) -> torch.tensor:
    """
    Computes the accuracy of the predicted output vs the ground truth,
    only for the last to_remember_len characters of every sequence.
    Args:
        -outputs: a tensor of shape [B, L, C], B being the batch size
        L being the sequence length and C being the unnormalized output
        of the "linear layer" of an RNN, one number for each of the C possible
        classes
        -ground_truth: a tensor of shape [B, L] containing the class indices
        for every sample of every sequence as a number in {0, ..., C-1}
    Returns:
        The average accuracy of the prediction for the last to_remember_len
        characters of every sequence
    """
    #####Insert your code here for subtask 2f#####
